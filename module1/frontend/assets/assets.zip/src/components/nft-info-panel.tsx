import { formatRelative, fromUnixTime } from 'date-fns';
import { MediaRenderer } from '@thirdweb-dev/react';
import { Constants } from '../common/constants';
import { ExternalLink } from './external-link';
import { ArrowLeftIcon, ArrowsRightLeftIcon, FireIcon } from '@heroicons/react/24/solid';
import { useNavigate } from 'react-router-dom';
import { useUser } from '../hooks/useUser';
import { useTransferNft } from '../hooks/useTransferNft';
import { SpinnerButton } from './spinner-button';
import { useBurnNft } from '../hooks/useBurnNft';
import { getNftCollectionAddress } from '../common/services/nfts';
import { Nft } from '../types/services/nfts';
import { truncateString } from '../common/util';

export const NFTInfoPanel = ({
  nft: { collectionId, id, owner, imageUrl, description, mintTransactionHash, timeMinted }
}: {
  nft: Nft;
}) => {
  const nftDescription = description || Constants.surpriseMeTextFriendly;
  const nftCollectionAddress = getNftCollectionAddress(collectionId);
  const navigate = useNavigate();
  const { user } = useUser();
  const isUserNftOwner = owner.toLowerCase() === user.account_address.toLowerCase();
  const { isLoading: isTransferring, promptTransfer } = useTransferNft({
    collectionId: collectionId,
    tokenId: id,
    rpcProvider: Constants.RPC_PROVIDER
  });
  const { isLoading: isBurning, promptBurn } = useBurnNft({
    tokenId: id,
    collectionId: collectionId,
    rpcProvider: Constants.RPC_PROVIDER
  });
  const isLoading = isTransferring || isBurning;

  return (
    <div className='grid gap-4 justify-center text-slate-900'>
      <div className='flex items-center gap-2 truncate'>
        <button onClick={() => navigate(-1)}>
          <ArrowLeftIcon className='w-8 h-8' />
        </button>
        <span className='truncate text-2xl font-bold'>{nftDescription}</span>
      </div>
      <div className='grid gap-4 justify-center'>
        {imageUrl && (
          <MediaRenderer
            src={imageUrl}
            gatewayUrl={'https://nftstorage.link/ipfs/'}
            className='mx-auto rounded-lg shadow ring-slate-200 ring-2'
            style={{
              width: 'inherit',
              height: 'inherit',
              objectFit: 'cover'
            }}
            alt={description}
          />
        )}
        {isUserNftOwner && (
          <div className='flex items-center gap-2'>
            <button
              disabled={isLoading}
              type='button'
              className='flex-1 inline-flex opacity-85 gap-1 justify-center items-center rounded-md bg-green-600 px-3 py-2 text-sm font-semibold text-white shadow-sm ring-1 ring-inset ring-green-300 hover:bg-green-700 disabled:bg-green-700'
              onClick={promptTransfer}
            >
              <>
                {isTransferring ? <SpinnerButton /> : <ArrowsRightLeftIcon className='h-5 w-5' />}
                Transfer
              </>
            </button>
            <button
              disabled={isLoading}
              type='button'
              className='flex-1 inline-flex opacity-85 gap-1 justify-center items-center rounded-md bg-orange-600 px-3 py-2 text-sm font-semibold text-white shadow-sm ring-1 ring-inset ring-orange-300 hover:bg-orange-700 disabled:bg-orange-700'
              onClick={promptBurn}
            >
              <>
                {isBurning ? <SpinnerButton /> : <FireIcon className='h-5 w-5' />}
                Burn
              </>
            </button>
          </div>
        )}
      </div>
      <div className='grid gap-3 bg-white p-4 rounded content-center'>
        <div className='grid'>
          <span className='font-bold'>Description</span>
          <span className='truncate'>{nftDescription}</span>
        </div>
        <div className='grid'>
          <span className='font-bold'>Token ID</span>
          <span>{id}</span>
        </div>
        <div className='grid'>
          <span className='font-bold'>Contract Address</span>
          <ExternalLink
            href={`https://sepolia.etherscan.io/address/${nftCollectionAddress}`}
            target={nftCollectionAddress}
          >
            {nftCollectionAddress}
          </ExternalLink>
        </div>
        {mintTransactionHash && (
          <div className='grid'>
            <span className='font-bold'>NFT Mint Transaction</span>
            <ExternalLink
              href={`https://sepolia.etherscan.io/tx/${mintTransactionHash}`}
              target={mintTransactionHash}
            >
              {truncateString(mintTransactionHash, 20, 20)}
            </ExternalLink>
          </div>
        )}
        <div className='grid'>
          <span className='font-bold'>Owner</span>
          <ExternalLink href={`https://sepolia.etherscan.io/address/${owner}`} target={owner}>
            {owner}
          </ExternalLink>
        </div>
        {timeMinted && (
          <div className='grid'>
            <span className='font-bold'>Created</span>
            {formatRelative(fromUnixTime(timeMinted), new Date())}
          </div>
        )}
      </div>
    </div>
  );
};
