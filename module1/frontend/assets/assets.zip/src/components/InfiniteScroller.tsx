import InfiniteScroll from 'react-infinite-scroll-component';
import { CSSProperties, ReactNode } from 'react';
import { Spinner } from './spinner';
import { Alert } from './alert';
import { useIsDocumentScrollable } from '../hooks/useIsDocumentScrollable';
import { useRunOnChange } from '../hooks/useRunOnChange';

type InfiniteScrollerProps = {
  isLoading: boolean;
  error: null | Error;
  items: any[];
  loadMore: () => Promise<void>;
  hasMore: boolean;
  style?: CSSProperties;
  children: ReactNode;
};

const InfiniteScroller: React.FC<InfiniteScrollerProps> = ({
  isLoading,
  error = null,
  items,
  loadMore,
  hasMore,
  style = {},
  children
}: InfiniteScrollerProps) => {
  const isScrollable = useIsDocumentScrollable([items]);

  useRunOnChange(() => {
    if (!isLoading && !isScrollable && hasMore) {
      loadMore();
    }
  }, [isLoading, isScrollable, hasMore]);

  return (
    <InfiniteScroll
      dataLength={items.length}
      next={loadMore}
      hasMore={hasMore}
      loader={<></>}
      style={{ overflow: 'hidden', ...style }}
    >
      {children}
      {isLoading && (
        <div className='flex justify-center items-center'>
          <Spinner />
        </div>
      )}
      {!isLoading && error && (
        <Alert
          severity='error'
          title='Error loading some items'
          message='Please refresh and try again'
        />
      )}
    </InfiniteScroll>
  );
};

export default InfiniteScroller;
