import { useBurnNft } from '../hooks/useBurnNft';
import { useTransferNft } from '../hooks/useTransferNft';
import { Nft } from '../types/services/nfts';
import { useUser } from '../hooks/useUser';
import { ArrowsRightLeftIcon, FireIcon } from '@heroicons/react/24/solid';
import { SpinnerButton } from './spinner-button';
import { Link } from 'react-router-dom';
import { Constants } from '../common/constants';
import { ListItem } from './list';

export const NftListItem = ({ collectionId, id, owner, description }: Nft) => {
  const { user } = useUser();
  const isUserNftOwner = owner.toLowerCase() === user.account_address.toLowerCase();
  const nftDetailsUrl = `/${collectionId}/${id}`;

  const { isLoading: isTransferring, promptTransfer } = useTransferNft({
    tokenId: id,
    collectionId,
    rpcProvider: Constants.RPC_PROVIDER
  });
  const { isLoading: isBurning, promptBurn } = useBurnNft({
    collectionId,
    tokenId: id,
    rpcProvider: Constants.RPC_PROVIDER
  });
  const isLoading = isTransferring || isBurning;

  return (
    <ListItem key={id}>
      <div className='flex-1 grid gap-2'>
        <Link to={nftDetailsUrl} className='text-blue-600 underline'>
          <span className='font-medium truncate'>
            {description || <em>No description found</em>}
          </span>
        </Link>
        <div className='flex items-center gap-2 text-sm text-slate-700'>
          <span>Token ID: {id}</span>
        </div>
      </div>
      {isUserNftOwner && (
        <div className={`${isLoading ? 'flex' : 'hidden'} group-hover:flex gap-2`}>
          <button
            disabled={isLoading}
            type='button'
            className='inline-flex opacity-85 gap-1 justify-center items-center rounded-md bg-green-600 px-3 py-2 text-sm font-semibold text-white shadow-sm ring-1 ring-inset ring-green-300 hover:bg-green-700 disabled:bg-green-700'
            onClick={promptTransfer}
          >
            <>
              {isTransferring ? <SpinnerButton /> : <ArrowsRightLeftIcon className='h-5 w-5' />}
              Transfer
            </>
          </button>
          <button
            disabled={isLoading}
            type='button'
            className='inline-flex opacity-85 gap-1 justify-center items-center rounded-md bg-orange-600 px-3 py-2 text-sm font-semibold text-white shadow-sm ring-1 ring-inset ring-orange-300 hover:bg-orange-700 disabled:bg-orange-700'
            onClick={promptBurn}
          >
            <>
              {isBurning ? <SpinnerButton /> : <FireIcon className='h-5 w-5' />}
              Burn
            </>
          </button>
        </div>
      )}
    </ListItem>
  );
};
