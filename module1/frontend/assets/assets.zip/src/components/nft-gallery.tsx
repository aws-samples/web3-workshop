import { Alert } from './alert';
import { NftCardList } from './nft-card-list';
import { defaultLoadMoreApiData } from '../common/services/api-gateway/api-gateway';
import InfiniteScroller from './InfiniteScroller';
import { Spinner } from './spinner';
import { NftList } from './nft-list';

type NftGalleryProps = {
  title?: string;
  subtitle?: string;
  list?: boolean;
  isLoading: boolean;
  error: Error | null;
  tokens: any[];
  loadMoreTokens?: () => Promise<void>;
  hasMoreTokens?: boolean;
};

export const NftGallery = ({
  title = 'NFT Gallery',
  subtitle = '',
  list = false,
  isLoading,
  error,
  tokens,
  loadMoreTokens = defaultLoadMoreApiData,
  hasMoreTokens = false
}: NftGalleryProps) => {
  return (
    <div className='grid gap-4 text-slate-900'>
      <h2 className='text-2xl font-semibold'>{title}</h2>
      {subtitle && <p>{subtitle}</p>}
      {!!tokens.length && (
        <InfiniteScroller
          isLoading={isLoading}
          error={error}
          items={tokens}
          loadMore={loadMoreTokens}
          hasMore={hasMoreTokens}
        >
          {list ? <NftList nfts={tokens} /> : <NftCardList nfts={tokens} />}
        </InfiniteScroller>
      )}
      {!tokens.length && isLoading && (
        <div className='flex justify-center items-center'>
          <Spinner />
        </div>
      )}
      {!tokens.length && !isLoading && error && (
        <Alert
          severity='error'
          title='Failed to load NFTs'
          message='Please refresh and try again'
        />
      )}
      {!error && !isLoading && !tokens.length && <Alert message='No NFTs minted yet' />}
    </div>
  );
};
