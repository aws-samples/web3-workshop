import { Nft } from '../types/services/nfts';
import { List } from './list';
import { NftListItem } from './nft-list-item';

export const NftList = ({ nfts }: { nfts: Nft[] }) => {
  return (
    <List>
      {nfts.map((nft: Nft) => (
        <NftListItem key={`${nft.collectionId}-${nft.id}`} {...nft} />
      ))}
    </List>
  );
};
