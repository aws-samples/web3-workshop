import { NetworkAddressHeader } from './network-address-header';
import { useUser } from '../hooks/useUser';
import { CopyToClipboard } from 'react-copy-to-clipboard';
import { DocumentDuplicateIcon } from '@heroicons/react/24/outline';
import { toast } from 'react-hot-toast';
import { truncateString } from '../common/util';

export const WalletHeader = () => {
  const {
    user: { account_address }
  } = useUser();

  const onCopyAddress = () => {
    toast.success('Address copied to clipboard');
  };

  return (
    <NetworkAddressHeader
      title='My Wallet'
      address={account_address}
      subtitle={
        <CopyToClipboard text={account_address} onCopy={onCopyAddress}>
          <span className='flex items-center gap-2'>
            {truncateString(account_address)}
            <DocumentDuplicateIcon className='h-5 w-5 cursor-pointer' />
          </span>
        </CopyToClipboard>
      }
    />
  );
};
