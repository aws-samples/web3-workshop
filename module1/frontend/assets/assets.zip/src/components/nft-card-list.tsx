import { Nft } from '../types/services/nfts';
import { NftCard } from './nft-card';

export const NftCardList = ({ nfts }: { nfts: Nft[] }) => {
  return (
    <ul className='grid gap-4 grid-cols-1 sm:grid-cols-1 md:grid-cols-4 mb-4'>
      {nfts.map((nft: Nft) => (
        <li key={nft.id}>
          <NftCard {...nft} />
        </li>
      ))}
    </ul>
  );
};
