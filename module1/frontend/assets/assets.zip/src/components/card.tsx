import { ReactNode } from 'react';
import { Link } from 'react-router-dom';

type CardProps = {
  href?: string;
  header?: ReactNode;
  title?: ReactNode;
  description?: ReactNode;
  footer?: ReactNode;
};

export const Card = ({ href, header, title = '', description = '', footer }: CardProps) => {
  const CardHeader = () => {
    if (header) {
      const className = 'rounded-top-lg bg-slate-200 -mb-6';

      if (href) {
        return (
          <Link to={href} className={className}>
            {header}
          </Link>
        );
      }

      return <div className={className}>{header}</div>;
    }

    return null;
  };

  return (
    <div className='bg-white border border-slate-200 rounded-lg shadow grid gap-3'>
      <CardHeader />
      <div className='p-6 grid gap-3 text-slate-900'>
        <h3 className='font-semibold text-2xl truncate'>{title}</h3>
        <span>{description}</span>
        {footer}
      </div>
    </div>
  );
};
