import { ReactNode, useState } from 'react';
import { ExternalLinkWorkshopModule } from './external-link-workshop-module';
import { NetworkAddressHeader } from './network-address-header';
import { Divider } from './divider';
import { Constants } from '../common/constants';
import { mintNftAndMonitorStatus } from '../common/services/nfts';
import { SpinnerButton } from './spinner-button';

const defaultFormFields = {
  prompt: '',
  beautify: false
};

type NftMintProps = {
  collectionId: string;
  collectionName: ReactNode;
  collectionModule: number;
  contractAddress: string;
  inputLabel: string;
  inputPlaceholder: string;
  maxInputLength?: number;
};

export const NftMint = ({
  collectionId,
  collectionName,
  collectionModule,
  contractAddress,
  inputLabel,
  inputPlaceholder,
  maxInputLength
}: NftMintProps) => {
  const [isLoading, setIsLoading] = useState(false);
  const [formFields, setFormFields] = useState(defaultFormFields);

  const isGenAiNft = collectionId == Constants.genAiNftCollectionId;
  const hasSurpriseMe = isGenAiNft;
  const hasBeautify = isGenAiNft;

  const handleChange = (event: {
    target: { name: any; value: any; type: string; checked: boolean };
  }) => {
    const { name, type, checked } = event.target;
    let { value } = event.target;

    value = type === 'checkbox' ? checked : value;

    setFormFields({ ...formFields, [name]: value });
  };

  const mintNft = async (prompt: string) => {
    setIsLoading(true);

    try {
      await mintNftAndMonitorStatus({
        collectionId,
        prompt,
        rpcProvider: Constants.RPC_PROVIDER
      });

      setFormFields(defaultFormFields);
    } catch {
      // Intentionally left blank
      // Async method called in the try{} block handle errors
    }

    setIsLoading(false);
  };

  const onFormSubmit = async (event: { preventDefault: () => void }) => {
    event.preventDefault();

    const prompt = `${formFields.prompt}${formFields.beautify ? '--beautify' : ''}`;

    mintNft(prompt);
  };

  const handleSurpriseMe = async (event: { preventDefault: () => void }) => {
    event.preventDefault();

    mintNft(Constants.surpriseMeText);
  };

  return (
    <NetworkAddressHeader
      title={collectionName}
      address={contractAddress}
      subtitle={
        <>
          Mint an NFT from the contract you deployed in{' '}
          <ExternalLinkWorkshopModule
            module={collectionModule}
            className='text-slate-900 underline'
          >
            Module {collectionModule}
          </ExternalLinkWorkshopModule>
          .
        </>
      }
    >
      <Divider className='max-w-2xl' />
      <form onSubmit={onFormSubmit} className='grid gap-4 w-full max-w-2xl'>
        <div className='grid gap-2'>
          <label htmlFor='prompt' className='font-semibold text-slate-900'>
            {inputLabel}
          </label>
          <input
            autoComplete='off'
            id={`prompt-${collectionId}`}
            required
            name='prompt'
            type='text'
            onChange={handleChange}
            placeholder={inputPlaceholder}
            className='text-slate-900 placeholder:text-slate-500 p-2 rounded-md shadow-sm ring-1 ring-slate-300 focus:ring-2 transition-all'
            autoFocus
            maxLength={maxInputLength}
            disabled={isLoading}
          />
          {hasBeautify && (
            <div className='flex items-center gap-2'>
              <input
                id='beautify'
                name='beautify'
                type='checkbox'
                onChange={handleChange}
                title='Beautify image'
                className='w-4 h-4 rounded accent-amber-500'
                disabled={isLoading}
              />
              <label htmlFor='beautify' className='font-semibold text-slate-900'>
                Beautify
              </label>
            </div>
          )}
        </div>
        <div className='w-full flex gap-2 mt-2'>
          <button
            type='submit'
            className='inline-flex gap-2 flex-1 justify-center rounded-md bg-amber-500 px-3 py-2 text-sm font-semibold text-slate-900 shadow-sm enabled:hover:bg-amber-600 sm:w-fit disabled:opacity-50'
            disabled={isLoading}
          >
            {isLoading && <SpinnerButton />}
            Mint
          </button>
          {hasSurpriseMe && (
            <button
              type='button'
              onClick={handleSurpriseMe}
              className='inline-flex gap-2 flex-1 justify-center rounded-md bg-slate-600 px-3 py-2 text-sm font-semibold text-white shadow-sm enabled:hover:bg-slate-700 sm:w-fit disabled:opacity-50'
              disabled={isLoading}
            >
              {isLoading && <SpinnerButton />}
              Surprise me
            </button>
          )}
        </div>
      </form>
    </NetworkAddressHeader>
  );
};
