import { MediaRenderer } from '@thirdweb-dev/react';
import { formatRelative, fromUnixTime } from 'date-fns';
import { Constants } from '../common/constants';
import { Link } from 'react-router-dom';
import { ArrowsRightLeftIcon, FireIcon } from '@heroicons/react/24/solid';
import { useUser } from '../hooks/useUser';
import { SpinnerButton } from './spinner-button';
import { useTransferNft } from '../hooks/useTransferNft';
import { useBurnNft } from '../hooks/useBurnNft';
import { Nft } from '../types/services/nfts';

export const NftCard = ({ collectionId, id, owner, imageUrl, description, timeMinted }: Nft) => {
  const { user } = useUser();
  const isUserNftOwner = owner.toLowerCase() === user.account_address.toLowerCase();
  const nftDetailsUrl = `/${collectionId}/${id}`;

  const { isLoading: isTransferring, promptTransfer } = useTransferNft({
    tokenId: id,
    collectionId,
    rpcProvider: Constants.RPC_PROVIDER
  });
  const { isLoading: isBurning, promptBurn } = useBurnNft({
    collectionId,
    tokenId: id,
    rpcProvider: Constants.RPC_PROVIDER
  });
  const isLoading = isTransferring || isBurning;

  return (
    <div className='bg-white border border-slate-200 rounded-lg shadow grid gap-3'>
      <div className='relative rounded-top-lg bg-slate-200 flex justify-center group'>
        <Link
          to={nftDetailsUrl}
          className='flex-1 aspect-h-3 aspect-w-4 rounded-t-lg overflow-hidden'
        >
          {imageUrl && (
            <MediaRenderer
              src={imageUrl}
              gatewayUrl={'https://nftstorage.link/ipfs/'}
              style={{
                width: 'inherit',
                height: 'inherit',
                objectFit: 'cover'
              }}
              alt={description}
            />
          )}
        </Link>
        {isUserNftOwner && (
          <div
            className={`absolute bottom-2 ${isLoading ? 'flex' : 'hidden'} group-hover:flex gap-2`}
          >
            <button
              disabled={isLoading}
              type='button'
              className='inline-flex opacity-85 gap-1 justify-center items-center rounded-md bg-green-600 px-3 py-2 text-sm font-semibold text-white shadow-sm ring-1 ring-inset ring-green-300 hover:bg-green-700 disabled:bg-green-700'
              onClick={promptTransfer}
            >
              <>
                {isTransferring ? <SpinnerButton /> : <ArrowsRightLeftIcon className='h-5 w-5' />}
                Transfer
              </>
            </button>
            <button
              disabled={isLoading}
              type='button'
              className='inline-flex opacity-85 gap-1 justify-center items-center rounded-md bg-orange-600 px-3 py-2 text-sm font-semibold text-white shadow-sm ring-1 ring-inset ring-orange-300 hover:bg-orange-700 disabled:bg-orange-700'
              onClick={promptBurn}
            >
              <>
                {isBurning ? <SpinnerButton /> : <FireIcon className='h-5 w-5' />}
                Burn
              </>
            </button>
          </div>
        )}
      </div>
      <Link to={nftDetailsUrl} className='p-4 pt-0 grid gap-1 text-slate-900 text-sm'>
        <span className='font-semibold truncate'>
          {description || Constants.surpriseMeTextFriendly}
        </span>
        {timeMinted && (
          <span className='text-slate-600'>
            {formatRelative(fromUnixTime(timeMinted), new Date())}
          </span>
        )}
      </Link>
    </div>
  );
};
