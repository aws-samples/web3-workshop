import { useLocation } from 'react-router-dom';
import LogoAmb from '../assets/images/logo-amb.png';
import { joinCssClasses } from '../common/util';
import { useRunOnChange } from '../hooks/useRunOnChange';
import { useState } from 'react';
import { ExternalLink } from './external-link';

export default function AmbWatermark() {
  const { pathname } = useLocation();
  const [expand, setExpand] = useState(false);
  const [className, setClassName] = useState('opacity-50');

  useRunOnChange(() => {
    setExpand(pathname == '/');
  }, pathname);

  useRunOnChange(() => {
    setClassName(expand ? 'opacity-100 translate-x-0' : 'opacity-50 translate-x-[235px]');
  }, expand);

  const onHoverStart = () => {
    setExpand(true);
  };

  const onHoverEnd = () => {
    setExpand(false);
  };

  return (
    <a
      target='amb'
      href='https://aws.amazon.com/managed-blockchain/'
      className='fixed top-30 right-0 z-[1] select-none'
    >
      <div
        className={joinCssClasses(
          'rounded-l-lg drop-shadow-lg p-3 bg-white text-slate-900 border border-slate-200 hover:translate-x-0 transition-all duration-500',
          className
        )}
        onMouseEnter={onHoverStart}
        onMouseLeave={onHoverEnd}
        onTouchStart={onHoverStart}
        onTouchEnd={onHoverEnd}
      >
        <div className='grid gap-1 relative'>
          <span className='absolute top-0 right-0 text-xs'>Powered by</span>
          <div className={'flex items-center relative gap-2'}>
            <img src={LogoAmb} alt='Amb' height={64} width={64} />
            <span>Amazon Managed Blockchain</span>
          </div>
          <ExternalLink
            className='absolute bottom-0 right-0 text-xs'
            href='https://aws.amazon.com/managed-blockchain/'
            target='amb'
          >
            Learn more
          </ExternalLink>
        </div>
      </div>
    </a>
  );
}
