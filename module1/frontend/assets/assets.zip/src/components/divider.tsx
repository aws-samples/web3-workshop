import { HTMLProps } from 'react';
import { joinCssClasses } from '../common/util';

type DividerProps = {
  className?: HTMLProps<HTMLElement>['className'];
};

export const Divider = ({ className = '' }: DividerProps) => {
  return <hr className={joinCssClasses('h-0.5 w-full border-t-0 bg-gray-900/10', className)} />;
};
