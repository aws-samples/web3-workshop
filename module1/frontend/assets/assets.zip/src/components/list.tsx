export const ListItem = ({
  children,
  className = ''
}: {
  children: React.ReactNode;
  className?: string;
}) => {
  return (
    <li
      className={`flex items-center p-4 bg-white border border-slate-200 rounded-lg shadow group ${className}`}
    >
      {children}
    </li>
  );
};

export const List = ({ children }: { children: React.ReactNode }) => {
  return <ul className='divide-y divide-slate-50 grid gap-4'>{children}</ul>;
};
