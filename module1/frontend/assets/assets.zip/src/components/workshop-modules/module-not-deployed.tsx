import { Constants } from '../../common/constants';
import { Alert } from '../alert';
import { ExternalLinkWorkshopModule } from '../external-link-workshop-module';

export type ModuleNotDeployedProps = {
  moduleNumber: number;
};

export const ModuleNotDeployed = ({ moduleNumber }: ModuleNotDeployedProps) => {
  const module = Constants.workshopModules.find(({ number }) => number == moduleNumber);

  if (!module) {
    return <Alert severity='error' message='Invalid workshop module.' />;
  }

  return (
    <div className='text-center grid gap-2 text-slate-900'>
      <Alert
        title={`Module ${module.number} not deployed`}
        message={`${module.name} are deployed are part of Module ${module.number} of the Web3 on AWS Workshop.
        Please complete Module ${module.number} and refresh this page to view your ${module.name}.`}
      />
      <em>
        Click here for more info: <ExternalLinkWorkshopModule module={module.number} />
      </em>
    </div>
  );
};
