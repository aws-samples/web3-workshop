import { ExternalLinkWorkshopModule } from '../external-link-workshop-module';

type ModuleCardProps = {
  module: number;
  title: string;
  description: string;
};

export const ModuleCard = ({ module, title, description }: ModuleCardProps) => {
  return (
    <div className='p-6 bg-white border border-slate-200 rounded-lg shadow grid gap-3'>
      <span className='flex gap-2 items-center font-semibold'>
        <h3 className='text-3xl text-amber-500'>{module}.</h3>
        <h4 className='text-2xl tracking-tight text-slate-900'>{title}</h4>
      </span>
      <p className='text-slate-900'>{description}.</p>
      <div className='self-end content-end'>
        <ExternalLinkWorkshopModule module={module}>
          Go to Module {module}
        </ExternalLinkWorkshopModule>
      </div>
    </div>
  );
};
