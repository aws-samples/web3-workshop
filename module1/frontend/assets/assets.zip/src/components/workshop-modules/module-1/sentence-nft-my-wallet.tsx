import { Constants } from '../../../common/constants';
import { useUserNfts } from '../../../hooks/useUserNfts';
import { NftGallery } from '../../nft-gallery';
import { SentenceNftNotDeployed } from './sentence-nft-not-deployed';

export const SentenceNftMyWallet = () => {
  const { sentenceNftContractAddress, sentenceNftCollectionId } = Constants;

  if (!sentenceNftContractAddress) {
    return <SentenceNftNotDeployed />;
  }

  const { isLoading, error, tokens, hasMore, loadMore } = useUserNfts({
    collectionId: sentenceNftCollectionId || ''
  });

  return (
    <NftGallery
      title='My Sentence NFTs'
      isLoading={isLoading}
      error={error}
      tokens={tokens}
      hasMoreTokens={hasMore}
      loadMoreTokens={loadMore}
      list={true}
    />
  );
};
