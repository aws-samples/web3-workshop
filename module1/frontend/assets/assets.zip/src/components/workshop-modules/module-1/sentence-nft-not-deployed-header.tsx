import { ModuleNotDeployedHeader } from '../module-not-deployed-header';

export const SentenceNftNotDeployedHeader = () => {
  return <ModuleNotDeployedHeader moduleNumber={1} />;
};
