import { NftMint } from '../../nft-mint';
import { Constants } from '../../../common/constants';
import { SentenceNftNotDeployedHeader } from './sentence-nft-not-deployed-header';

export const SentenceNftMint = () => {
  const { sentenceNftContractAddress, sentenceNftCollectionId, sentenceNftCollectionName } =
    Constants;

  if (!sentenceNftContractAddress) {
    return <SentenceNftNotDeployedHeader />;
  }

  return (
    <NftMint
      collectionId={sentenceNftCollectionId || ''}
      inputLabel='What sentence would you like to inscribe into your NFT?'
      inputPlaceholder='This NFT was generated on AWS!'
      collectionName={sentenceNftCollectionName}
      collectionModule={1}
      contractAddress={sentenceNftContractAddress}
      maxInputLength={256}
    />
  );
};
