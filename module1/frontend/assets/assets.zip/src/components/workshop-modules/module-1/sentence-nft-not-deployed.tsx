import { ModuleNotDeployed } from '../module-not-deployed';

export const SentenceNftNotDeployed = () => {
  return <ModuleNotDeployed moduleNumber={1} />;
};
