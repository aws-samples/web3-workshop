import { NftGallery } from '../../nft-gallery';
import { Constants } from '../../../common/constants';
import { useNfts } from '../../../hooks/useNfts';
import { SentenceNftNotDeployed } from './sentence-nft-not-deployed';

export const SentenceNftGallery = () => {
  const { sentenceNftContractAddress, sentenceNftCollectionId, sentenceNftCollectionName } =
    Constants;

  if (!sentenceNftContractAddress) {
    return <SentenceNftNotDeployed />;
  }

  const { tokens, isLoading, error, hasMore, loadMore } = useNfts({
    collectionId: sentenceNftCollectionId || ''
  });

  return (
    <NftGallery
      title={`${sentenceNftCollectionName} Gallery`}
      subtitle='Take a look at all the NFTs minted by your contract.'
      isLoading={isLoading}
      error={error}
      tokens={tokens}
      hasMoreTokens={hasMore}
      loadMoreTokens={loadMore}
      list={true}
    />
  );
};
