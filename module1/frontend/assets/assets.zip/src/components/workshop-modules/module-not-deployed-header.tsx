import { Constants } from '../../common/constants';
import { Alert } from '../alert';
import { ModuleNotDeployedProps } from './module-not-deployed';

export const ModuleNotDeployedHeader = ({ moduleNumber }: ModuleNotDeployedProps) => {
  const module = Constants.workshopModules.find(({ number }) => number == moduleNumber);

  if (!module) {
    return <Alert severity='error' message='Invalid workshop module.' />;
  }

  return <h2 className='text-3xl text-center font-bold text-slate-900'>{module.name}</h2>;
};
