import { Constants } from '../../../common/constants';
import { useTransactions } from '../../../hooks/useTransactions';
import { useUser } from '../../../hooks/useUser';
import { Alert } from '../../alert';
import { List } from '../../list';
import { Spinner } from '../../spinner';
import { ModuleNotDeployed } from '../module-not-deployed';
import { TransactionListItem } from './transaction-list-item';

export const TransactionList = () => {
  const { genAiNftContractAddress } = Constants;

  if (!genAiNftContractAddress) {
    return <ModuleNotDeployed moduleNumber={2} />;
  }

  const {
    user: { account_address }
  } = useUser();

  const { transactions, isLoading, error } = useTransactions(account_address);

  if (isLoading) {
    return (
      <div className='flex justify-center items-center'>
        <Spinner />
      </div>
    );
  } else if (error) {
    return (
      <Alert
        severity='error'
        title='Error loading transactions'
        message='Please refresh and try again'
      />
    );
  } else if (!transactions.length) {
    return <Alert message='No transactions yet' />;
  }

  return (
    <List>
      {transactions.map((transaction) => (
        <TransactionListItem {...transaction} />
      ))}
    </List>
  );
};
