import { Constants } from '../../../common/constants';
import { TransactionList } from './transaction-list';
import { TransactionsNotDeployed } from './transactions-not-deployed';

export const TransactionListMyWallet = () => {
  const { genAiNftContractAddress } = Constants;

  if (!genAiNftContractAddress) {
    return <TransactionsNotDeployed />;
  }

  return (
    <div className='grid gap-4 text-slate-900'>
      <h2 className='text-2xl font-semibold'>My Transactions</h2>
      <TransactionList />
    </div>
  );
};
