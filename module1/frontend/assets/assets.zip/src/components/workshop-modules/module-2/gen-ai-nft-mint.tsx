import { NftMint } from '../../nft-mint';
import { Constants } from '../../../common/constants';
import { GenAiNftNotDeployedHeader } from './gen-ai-nft-not-deployed-header';

export const GenAiNftMint = () => {
  const { genAiNftContractAddress, genAiNftCollectionName, genAiNftCollectionId } = Constants;

  if (!genAiNftContractAddress) {
    return <GenAiNftNotDeployedHeader />;
  }

  return (
    <NftMint
      collectionId={genAiNftCollectionId || ''}
      inputLabel='What artwork would you like to create?'
      inputPlaceholder='Man playing guitar in oil paint of Van Gogh style'
      collectionName={genAiNftCollectionName}
      collectionModule={2}
      contractAddress={genAiNftContractAddress}
    />
  );
};
