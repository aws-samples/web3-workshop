import { NftGallery } from '../../nft-gallery';
import { Constants } from '../../../common/constants';
import { ModuleNotDeployed } from '../module-not-deployed';
import { useNfts } from '../../../hooks/useNfts';

export const GenAiNftGallery = () => {
  const { genAiNftContractAddress, genAiNftCollectionName, genAiNftCollectionId } = Constants;

  if (!genAiNftContractAddress) {
    return <ModuleNotDeployed moduleNumber={2} />;
  }

  const { tokens, isLoading, error, hasMore, loadMore } = useNfts({
    collectionId: genAiNftCollectionId || ''
  });

  return (
    <NftGallery
      title={`${genAiNftCollectionName} Gallery`}
      subtitle="Here's the artwork that's been generated with your contract so far."
      isLoading={isLoading}
      error={error}
      tokens={tokens}
      hasMoreTokens={hasMore}
      loadMoreTokens={loadMore}
    />
  );
};
