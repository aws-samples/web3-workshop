import { Alert } from '../../alert';
import { ExternalLinkWorkshopModule } from '../../external-link-workshop-module';

export const TransactionsNotDeployed = () => {
  return (
    <div className='text-center grid gap-2 text-slate-900'>
      <Alert
        title='Module 2 not deployed'
        message={`The backend required to list Transactions is deployed are part of Module 2 of the Web3 on AWS Workshop.
        Please complete Module 2 and refresh this page to view your Transactions.`}
      />
      <em>
        Click here for more info: <ExternalLinkWorkshopModule module={2} />
      </em>
    </div>
  );
};
