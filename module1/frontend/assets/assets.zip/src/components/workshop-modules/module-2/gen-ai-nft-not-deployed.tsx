import { ModuleNotDeployed } from '../module-not-deployed';

export const GenAiNftNotDeployed = () => {
  return <ModuleNotDeployed moduleNumber={2} />;
};
