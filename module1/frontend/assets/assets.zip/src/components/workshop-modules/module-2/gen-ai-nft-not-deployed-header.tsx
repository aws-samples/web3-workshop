import { ModuleNotDeployedHeader } from '../module-not-deployed-header';

export const GenAiNftNotDeployedHeader = () => {
  return <ModuleNotDeployedHeader moduleNumber={2} />;
};
