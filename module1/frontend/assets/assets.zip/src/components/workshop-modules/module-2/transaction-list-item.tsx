import {
  ArrowDownCircleIcon,
  ArrowUpCircleIcon,
  ArrowsRightLeftIcon,
  FireIcon,
  PhotoIcon,
  QuestionMarkCircleIcon
} from '@heroicons/react/24/solid';
import { capitalize, truncateString } from '../../../common/util';
import { useUser } from '../../../hooks/useUser';
import { Transaction } from '../../../types/services/transactions';
import { ListItem } from '../../list';
import { getNftCollectionName } from '../../../common/services/nfts';
import { ExternalLink } from '../../external-link';

export const TransactionListItem = ({
  contractAddress,
  eventType,
  to,
  from,
  tokenId,
  transactionHash
}: Transaction) => {
  const {
    user: { account_address }
  } = useUser();
  const userAddress = account_address.toLowerCase();
  to = to?.toLowerCase();
  from = from?.toLowerCase();
  const collectionName = getNftCollectionName(contractAddress) || truncateString(contractAddress);

  let transactionAction = capitalize(eventType.toLowerCase().split('_').join(' '));

  if (!from && to == userAddress) {
    transactionAction = 'Mint';
  } else if (!to && from == userAddress) {
    transactionAction = 'Burn';
  } else if (from && to) {
    transactionAction = 'Transfer';

    if (from == userAddress) {
      transactionAction = 'Send';
    } else if (to == userAddress) {
      transactionAction = 'Receive';
    }
  }

  let TransactionIcon = QuestionMarkCircleIcon;
  let transactionColor = 'text-blue-500';

  switch (transactionAction) {
    case 'Mint':
      TransactionIcon = PhotoIcon;
      transactionColor = 'text-blue-500';
      break;
    case 'Burn':
      TransactionIcon = FireIcon;
      transactionColor = 'text-orange-600';
      break;
    case 'Transfer':
      TransactionIcon = ArrowsRightLeftIcon;
      transactionColor = 'text-green-500';
      break;
    case 'Send':
      TransactionIcon = ArrowUpCircleIcon;
      transactionColor = 'text-red-500';
      break;
    case 'Receive':
      TransactionIcon = ArrowDownCircleIcon;
      transactionColor = 'text-green-500';
      break;
  }

  return (
    <ListItem className='gap-4'>
      <TransactionIcon className={`w-8 h-8 ${transactionColor}`} />
      <div className='flex-1 grid gap-1'>
        <h3 className='font-semibold'>{transactionAction}</h3>
        <h4 className='text-sm flex'>
          {collectionName} token #{parseInt(tokenId)}
        </h4>
      </div>
      <ExternalLink
        href={`https://goerli.etherscan.io/tx/${transactionHash}`}
        target={transactionHash}
      >
        View on Etherscan
      </ExternalLink>
    </ListItem>
  );
};
