import { NftGallery } from '../../nft-gallery';
import { Constants } from '../../../common/constants';
import { useUserNfts } from '../../../hooks/useUserNfts';
import { GenAiNftNotDeployed } from './gen-ai-nft-not-deployed';

export const GenAiNftMyWallet = () => {
  const { genAiNftContractAddress, genAiNftCollectionId } = Constants;

  if (!genAiNftContractAddress) {
    return <GenAiNftNotDeployed />;
  }

  const { tokens, isLoading, error, hasMore, loadMore } = useUserNfts({
    collectionId: genAiNftCollectionId || ''
  });

  return (
    <NftGallery
      title='My GenAI NFTs'
      isLoading={isLoading}
      error={error}
      tokens={tokens}
      hasMoreTokens={hasMore}
      loadMoreTokens={loadMore}
    />
  );
};
