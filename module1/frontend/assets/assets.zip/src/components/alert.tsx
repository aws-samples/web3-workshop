import { ExclamationCircleIcon, InformationCircleIcon } from '@heroicons/react/24/solid';

type AlertProps = {
  severity?: 'info' | 'error';
  title?: string;
  message: string;
};

export const Alert = ({ severity = 'info', title, message }: AlertProps) => {
  let alertStyleColor = 'flex p-4 gap-3 rounded-lg text-left';
  let Icon;

  switch (severity) {
    case 'info':
      alertStyleColor += ' text-blue-800 bg-blue-100';
      Icon = InformationCircleIcon;
      break;
    case 'error':
      alertStyleColor += ' text-red-800 bg-red-100';
      Icon = ExclamationCircleIcon;
  }

  return (
    <div className={alertStyleColor} role='alert'>
      <Icon className='w-5 h-5' />
      <div className='grid gap-1'>
        {title && <span className='font-semibold text-md'>{title}</span>}
        {message}
      </div>
    </div>
  );
};
