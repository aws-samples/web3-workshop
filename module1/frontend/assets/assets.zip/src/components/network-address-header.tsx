import { ReactNode } from 'react';
import { ExternalLink } from './external-link';

type NetworkAddressHeaderProps = {
  address: string;
  title: ReactNode;
  subtitle?: ReactNode;
  children?: ReactNode;
};

export const NetworkAddressHeader = ({
  address,
  title,
  subtitle,
  children
}: NetworkAddressHeaderProps) => {
  return (
    <div className='grid gap-4 justify-items-center'>
      <div className='flex items-center gap-2'>
        <h2 className='text-3xl font-bold text-slate-900'>{title}</h2>
        <ExternalLink
          href={`https://goerli.etherscan.io/address/${address}`}
          target={`etherscan-contract-${address}`}
          className='text-slate-900 underline'
        >
          View on Etherscan
        </ExternalLink>
      </div>
      {subtitle && <p className='text-lg text-slate-900'>{subtitle}</p>}
      {children}
    </div>
  );
};
