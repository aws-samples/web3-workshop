import { Spinner } from './spinner';

export const SpinnerButton = () => {
  return <Spinner className='w-5 h-5 fill-white' />;
};
