import { Constants } from '../common/constants';
import { ExternalLink, ExternalLinkProps } from './external-link';

type ExternalLinkWorkshopModuleProps = Omit<ExternalLinkProps, 'href'> & {
  module: number;
};

export const ExternalLinkWorkshopModule = ({
  module,
  ...externalLinkProps
}: ExternalLinkWorkshopModuleProps) => {
  return (
    <ExternalLink
      {...externalLinkProps}
      target={`workshop-module-${module}`}
      href={`${Constants.urlWorkshop}/module${module}`}
    />
  );
};
