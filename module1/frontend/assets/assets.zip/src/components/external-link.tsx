import { ArrowTopRightOnSquareIcon } from '@heroicons/react/24/outline';
import { ReactNode } from 'react';
import { joinCssClasses } from '../common/util';

export type ExternalLinkProps = {
  href: string;
  target?: string;
  className?: string;
  children?: ReactNode;
};

export const ExternalLink = ({
  href,
  target = '_blank',
  children,
  className = ''
}: ExternalLinkProps) => {
  return (
    <a
      className={joinCssClasses('inline-flex items-center gap-1 mt-1 text-blue-600', className)}
      href={href}
      target={target}
    >
      {children || href} <ArrowTopRightOnSquareIcon className='h-4 w-4' />
    </a>
  );
};
