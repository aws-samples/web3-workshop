import { createBrowserRouter } from 'react-router-dom';
import { Constants } from './common/constants';
import { Layout } from './routes/layout';
import { Home } from './routes/home';
import { ViewNFT } from './routes/view-nft';
import { SentenceNft } from './routes/sentence-nft';
import { GenAiNft } from './routes/gen-ai-nft';
import { MyWallet } from './routes/my-wallet';
import { Error } from './routes/error';
import Login from './routes/login';

export const getRouter = (isLoggedIn: boolean) => {
  const childRoutes: any[] = [
    { path: Constants.pathHome, index: true, canShow: true, element: <Home /> },
    {
      path: Constants.pathSentenceNft,
      canShow: isLoggedIn,
      element: <SentenceNft />
    },
    {
      path: Constants.pathGenAiNft,
      canShow: isLoggedIn,
      element: <GenAiNft />
    },
    {
      path: Constants.pathMyWallet,
      canShow: isLoggedIn,
      element: <MyWallet />
    },
    {
      path: Constants.pathViewNft,
      canShow: isLoggedIn,
      element: <ViewNFT />
    },
    {
      path: Constants.pathLogin,
      canShow: true,
      element: <Login />
    },
    { path: '*', canShow: true, element: <Error /> }
  ];

  const visibleRoutes = childRoutes
    .filter((f) => f.canShow)
    .map((i) => {
      return { index: i.index, path: i.path, element: i.element };
    });

  const routes: any[] = [
    {
      element: <Layout />,
      children: visibleRoutes
    }
  ];

  return createBrowserRouter(routes);
};
