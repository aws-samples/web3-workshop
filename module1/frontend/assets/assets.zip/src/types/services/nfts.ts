export type Nft = {
  contractAddress: string;
  collectionId: string;
  id: string;
  owner: string;
  imageUrl: string;
  description: string;
  mintTransactionHash?: string;
  timeMinted?: number;
};

export type NftQueryResponse = {
  nfts: Nft[];
  nextPage?: number;
};

export type NftCollectionInput = {
  collectionId: string;
  page?: number;
};

export type NftCollectionOwnedInput = NftCollectionInput & {
  ownerAddress: string;
};

export type NftInput = NftCollectionInput & {
  tokenId: string;
  rpcProvider?: any;
};

export type MintNftInput = NftCollectionInput & {
  prompt?: string;
};

export type MintNftCheckStatusInput = MintNftInput & {
  rpcProvider: any;
};

export type NftMintStatusInput = {
  executionArn: string;
};

export type TransferNftInput = NftInput & {
  toAddress: string;
};

import * as NftApiRequestFunctionNames from '../../common/services/api-gateway/api-gateway-nfts';

export type NftApiMethod = keyof typeof NftApiRequestFunctionNames;

type NftApiMethodPayloadLookup = {
  mintNft: MintNftInput;
  getNftMintStatus: NftMintStatusInput;
  getNfts: NftCollectionInput;
  getOwnedNfts: NftCollectionOwnedInput;
  getNft: NftInput;
  transferNft: TransferNftInput;
  burnNft: NftInput;
};

export type NftApiPayload = {
  [apiMethod in keyof NftApiMethodPayloadLookup]: NftApiMethodPayloadLookup[apiMethod];
};
