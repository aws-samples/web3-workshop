import { GenericObject } from '../objects';

export type AmplifyApiGatewayRequestInput = {
  headers?: GenericObject;
  queryStringParameters?: GenericObject;
  body?: GenericObject;
};

export type AmplifyApiGatewayMethod = 'post' | 'get' | 'patch' | 'del';

export type LoadMoreApiData = () => Promise<void>;
