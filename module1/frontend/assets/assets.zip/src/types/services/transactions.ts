export type Transaction = {
  contractAddress: string;
  eventType: string;
  to?: string;
  from?: string;
  tokenId?: string;
  transactionHash: string;
  value: string;
};
