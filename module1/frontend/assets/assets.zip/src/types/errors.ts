export type HttpError = Error & {
  statusCode: number;
};

export type AmplifyHttpError = Error & {
  response: { status: number };
};
