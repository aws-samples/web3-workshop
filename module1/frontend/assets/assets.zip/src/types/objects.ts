export type GenericObject = {
  [key: string]: any;
};
