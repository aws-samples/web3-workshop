import { GenAiNftGallery } from '../components/workshop-modules/module-2/gen-ai-nft-gallery';
import { GenAiNftMint } from '../components/workshop-modules/module-2/gen-ai-nft-mint';

export const GenAiNft = () => {
  return (
    <div className='flex flex-col gap-4'>
      <GenAiNftMint />
      <GenAiNftGallery />
    </div>
  );
};
