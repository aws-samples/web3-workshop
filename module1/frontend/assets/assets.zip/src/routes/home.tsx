import { Divider } from '../components/divider';
import { ModuleCard } from '../components/workshop-modules/module-card';
import { useUser } from '../hooks/useUser';
import { Constants } from '../common/constants';
import { useNavigate } from 'react-router-dom';
import { ExternalLink } from '../components/external-link';

export const Home = () => {
  const { isAuthenticated } = useUser();
  const navigate = useNavigate();

  return (
    <div className='grid gap-4'>
      <div className='p-4 grid gap-4'>
        <h1 className='mx-auto max-w-2xl text-6xl text-center font-bold text-slate-900'>
          Welcome to the Web3 on AWS Workshop
        </h1>
        <div className='text-center mt-4 text-lg text-slate-900 grid gap-2 justify-items-center'>
          <p>
            We are delighted you're here. This workshop showcases Web3 workloads on AWS including
            account abstraction, NFT minting, generative AI, smart contract deployment, dApp
            development, and more!
          </p>

          <ExternalLink href={Constants.urlWorkshop}>Go to Workshop</ExternalLink>
          {!isAuthenticated && (
            <>
              <Divider className='w-1/3 my-4' />
              <p>To get started, login or signup with an email address.</p>
              <button
                onClick={() => {
                  navigate('/login');
                }}
                className='rounded-md bg-amber-500 px-3.5 py-2.5 text-sm font-semibold text-slate-900 shadow-sm hover:bg-amber-600'
              >
                Get started
              </button>
            </>
          )}
        </div>
      </div>
      <h2 className='text-3xl font-semibold text-slate-900'>Modules</h2>
      <div
        className='grid sm:grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4'
        style={{ gridAutoRows: '1fr' }}
      >
        {Constants.workshopModules.map(({ name, number, description }) => (
          <ModuleCard
            key={`module-${number}`}
            module={number}
            title={name}
            description={description}
          />
        ))}
      </div>
    </div>
  );
};
