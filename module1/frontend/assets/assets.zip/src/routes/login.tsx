import { Authenticator, useAuthenticator } from '@aws-amplify/ui-react';
import { useNavigate } from 'react-router-dom';
import { useRunOnChange } from '../hooks/useRunOnChange';
import { useUser } from '../hooks/useUser';
import { Spinner } from '../components/spinner';

/**
 * AWS Amplify Authenticator Component used by users to signup and login
 */
export default function Login() {
  const { authStatus, isPending } = useAuthenticator(({ authStatus, isPending }) => [
    authStatus,
    isPending
  ]);
  const navigate = useNavigate();
  const { getAndSetUser } = useUser();

  useRunOnChange(() => {
    const onAuthenticate = async () => {
      await getAndSetUser();

      navigate('/', { replace: true });
    };

    if (authStatus === 'authenticated') {
      onAuthenticate();
    }
  }, [authStatus]);

  if (isPending) {
    return <Spinner />;
  }

  return <Authenticator loginMechanisms={['email']} />;
}
