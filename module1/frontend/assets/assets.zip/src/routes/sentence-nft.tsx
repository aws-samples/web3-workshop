import { SentenceNftMint } from '../components/workshop-modules/module-1/sentence-nft-mint';
import { SentenceNftGallery } from '../components/workshop-modules/module-1/sentence-nft-gallery';

export const SentenceNft = () => {
  return (
    <div className='flex flex-col gap-4'>
      <SentenceNftMint />
      <SentenceNftGallery />
    </div>
  );
};
