import { Spinner } from '../components/spinner';
import { useParams } from 'react-router-dom';
import { NFTInfoPanel } from '../components/nft-info-panel';
import { useState } from 'react';
import { getNftCollectionAddress, getNftCollectionName } from '../common/services/nfts';
import { Alert } from '../components/alert';
import { getNft } from '../common/services/api-gateway/api-gateway-nfts';
import { Nft } from '../types/services/nfts';
import { useRunOnce } from '../hooks/useRunOnce';

export const ViewNFT = () => {
  const { collectionId, tokenId } = useParams();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [token, setToken] = useState<Nft>();

  useRunOnce(() => {
    if (collectionId && tokenId) {
      setLoading(true);
      const fetchNft = async () => {
        try {
          const { nfts } = await getNft({ collectionId, tokenId });
          const [nft] = nfts;

          setToken(nft);
        } catch {
          setError(true);
        } finally {
          setLoading(false);
        }
      };

      fetchNft();
    }
  });

  if (!collectionId || !tokenId) {
    setError(true);
  }

  return (
    <>
      {loading && <Spinner />}
      {!loading && error && (
        <Alert
          severity='error'
          title={`Failed to fetch NFT ${tokenId} from collection ${getNftCollectionName(
            getNftCollectionAddress(collectionId || '')
          )}`}
          message='Please refresh and try again'
        />
      )}
      {token && <NFTInfoPanel nft={token} />}
    </>
  );
};
