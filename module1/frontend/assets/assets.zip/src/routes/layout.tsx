import { useState } from 'react';
import { Disclosure } from '@headlessui/react';
import { Bars3Icon, XMarkIcon } from '@heroicons/react/24/outline';
import { Link, Outlet, useLocation, useNavigate } from 'react-router-dom';
import { Constants } from '../common/constants';
import { joinCssClasses } from '../common/util';
import { useUser } from '../hooks/useUser';
import { Spinner } from '../components/spinner';
import { UserCircleIcon } from '@heroicons/react/24/solid';
import { useRunOnChange } from '../hooks/useRunOnChange';
import AmbWatermark from '../components/amb-watermark';

type NavItem = {
  name: string;
  url: string;
  isCurrent: boolean;
  handler?: any;
  isVisible: boolean;
};

export const Layout = () => {
  const [location, setLocation] = useState('');
  const { user, isAuthenticated, isLoading, signOut } = useUser();
  const [navigation, setNavigation] = useState<NavItem[] | []>([]);
  const navigate = useNavigate();

  const signInSignOut = async () => {
    if (!isAuthenticated) {
      navigate('/login');
    } else {
      await signOut();
      navigate('/');
    }
  };

  const loc = useLocation();

  useRunOnChange(() => {
    setLocation(loc.pathname);
  }, [loc]);

  useRunOnChange(() => {
    setNavigation([
      {
        name: 'Home',
        url: `${Constants.pathHome}`,
        isCurrent: Constants.pathHome === location,
        isVisible: true
      },
      {
        name: 'Sentence NFT',
        url: `${Constants.pathSentenceNft}`,
        isCurrent: Constants.pathSentenceNft === location,
        isVisible: isAuthenticated
      },
      {
        name: 'Gen AI NFT',
        url: `${Constants.pathGenAiNft}`,
        isCurrent: Constants.pathGenAiNft === location,
        isVisible: isAuthenticated
      },
      {
        name: 'My Wallet',
        url: `${Constants.pathMyWallet}`,
        isCurrent: Constants.pathMyWallet === location,
        isVisible: isAuthenticated
      },
      {
        name: !isAuthenticated ? 'Login' : 'Logout',
        url: `${Constants.pathLogin}`,
        isCurrent: Constants.pathLogin === location,
        handler: signInSignOut,
        isVisible: true
      }
    ]);
  }, [isAuthenticated, location]);

  return (
    <div className='h-screen flex flex-col'>
      <Disclosure as='nav' className='bg-gray-800 sticky top-0 z-10'>
        {({ open }) => (
          <>
            <div className='px-4 sm:px-6 lg:px-8'>
              <div className='flex h-16 items-center justify-between'>
                <div className='flex lg:hidden'>
                  {/* Mobile menu button */}
                  <Disclosure.Button className='inline-flex items-center justify-center rounded-md bg-gray-800 p-2 text-slate-400 hover:bg-gray-700 hover:text-white focus:outline-none focus:ring-2 focus:ring-white focus:ring-offset-2 focus:ring-offset-gray-800'>
                    <span className='sr-only'>Open main menu</span>
                    {open ? (
                      <XMarkIcon className='block h-6 w-6' aria-hidden='true' />
                    ) : (
                      <Bars3Icon className='block h-6 w-6' aria-hidden='true' />
                    )}
                  </Disclosure.Button>
                </div>
                <div className='flex items-center'>
                  <div className='flex-shrink-0'>
                    <Link to={Constants.pathHome}>
                      <img
                        width={80}
                        height={80}
                        src='https://d0.awsstatic.com/logos/powered-by-aws-white.png'
                        alt='Powered by AWS'
                      />
                    </Link>
                  </div>
                  <div className='hidden lg:block'>
                    <div className='ml-10 flex items-baseline space-x-4'>
                      {navigation
                        .filter((f: NavItem) => f.isVisible)
                        .map(({ name, url, handler, isCurrent }) => (
                          <Link
                            key={name}
                            to={url}
                            onClick={handler}
                            className={joinCssClasses(
                              isCurrent
                                ? 'bg-amber-500 text-slate-900 font-semibold'
                                : 'text-slate-50 hover:bg-slate-600 hover:text-white',
                              'rounded-md px-3 py-2 text-sm'
                            )}
                            aria-current={isCurrent ? 'page' : undefined}
                          >
                            {name}
                          </Link>
                        ))}
                    </div>
                  </div>
                </div>
                {isAuthenticated && (
                  <div className='flex flex-1 items-center justify-end gap-2 text-slate-50 truncate'>
                    <UserCircleIcon className='h-7 w-7' />
                    <span className='truncate max-w-xs'>{user.email}</span>
                  </div>
                )}
              </div>
            </div>
            <Disclosure.Panel className='lg:hidden'>
              <div className='space-y-1 px-2 pb-3 pt-2 sm:px-3'>
                {navigation
                  .filter((f: NavItem) => f.isVisible)
                  .map(({ name, url, handler, isCurrent }) => (
                    <Disclosure.Button
                      key={name}
                      as='a'
                      href={url}
                      onClick={handler}
                      className={joinCssClasses(
                        isCurrent
                          ? 'bg-slate-950 text-slate-50'
                          : 'text-slate-200 hover:bg-slate-700 hover:text-slate-50',
                        'block rounded-md px-3 py-2 text-base font-medium'
                      )}
                      aria-current={isCurrent ? 'page' : undefined}
                    >
                      {name}
                    </Disclosure.Button>
                  ))}
              </div>
            </Disclosure.Panel>
          </>
        )}
      </Disclosure>
      <main className='flex-1 p-4 relative bg-slate-100'>
        <div className='mx-auto max-w-7xl'>
          <AmbWatermark />
          {isLoading ? <Spinner /> : <Outlet />}
        </div>
      </main>
    </div>
  );
};
