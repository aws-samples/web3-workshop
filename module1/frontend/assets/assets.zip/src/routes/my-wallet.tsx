import { joinCssClasses } from '../common/util';
import { Tab } from '@headlessui/react';
import { WalletHeader } from '../components/wallet-header';
import { SentenceNftMyWallet } from '../components/workshop-modules/module-1/sentence-nft-my-wallet';
import { GenAiNftMyWallet } from '../components/workshop-modules/module-2/gen-ai-nft-my-wallet';
import { TransactionListMyWallet } from '../components/workshop-modules/module-2/transaction-list-my-wallet';

export const MyWallet = () => {
  /* Define tabs for each NFT collection */

  const tabs = {
    'Sentence NFT': <SentenceNftMyWallet />,
    'Gen AI NFT': <GenAiNftMyWallet />,
    Transactions: <TransactionListMyWallet />
  };

  return (
    <div className='grid gap-4'>
      <WalletHeader />
      <Tab.Group>
        <Tab.List className='flex gap-1 rounded-xl bg-slate-200 p-1'>
          {Object.keys(tabs).map((tabName) => (
            <Tab
              key={tabName}
              className={({ selected }) =>
                joinCssClasses(
                  'w-full rounded-lg py-2.5 font-semibold text-slate-900',
                  selected ? 'bg-amber-500 text-slate-900 shadow' : 'hover:bg-slate-100'
                )
              }
            >
              {tabName}
            </Tab>
          ))}
        </Tab.List>
        <Tab.Panels>
          {Object.values(tabs).map((element, i) => (
            <Tab.Panel key={i} className='px-4'>
              {element}
            </Tab.Panel>
          ))}
        </Tab.Panels>
      </Tab.Group>
    </div>
  );
};
