export const Error = () => {
  return (
    <>
      <span>error</span>
    </>
  );
};
