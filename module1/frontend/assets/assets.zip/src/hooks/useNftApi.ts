import { useState } from 'react';
import { NftApiMethod, NftApiPayload, NftQueryResponse } from '../types/services/nfts';
import { LoadMoreApiData } from '../types/services/amplify-api-gateway';
import * as NftApiRequestFunctionNames from '../common/services/api-gateway/api-gateway-nfts';
import { HttpError } from '../types/errors';
import { defaultLoadMoreApiData } from '../common/services/api-gateway/api-gateway';
import { useRunOnce } from './useRunOnce';

function loadNftApiMethod<K extends NftApiMethod>(
  functionName: K
): (typeof NftApiRequestFunctionNames)[K] {
  return NftApiRequestFunctionNames[functionName];
}

type UseNftApi = {
  isLoading: boolean;
  error: Error | null;
  result: NftQueryResponse | null;
  hasMore: boolean;
  loadMore: LoadMoreApiData;
};

export function useNftApi<T extends NftApiMethod>(method: T, params: NftApiPayload[T]): UseNftApi {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<Error | null>(null);
  const [result, setResult] = useState<UseNftApi['result'] | null>(null);
  const [hasMore, setHasMore] = useState<boolean>(false);
  const [loadMore, setLoadMore] = useState<LoadMoreApiData>(() => defaultLoadMoreApiData);

  useRunOnce(() => {
    async function fetchNftApi<T extends NftApiMethod>(method: T, params: NftApiPayload[T]) {
      setIsLoading(true);

      const nftApiMethod = loadNftApiMethod(method);
      let result: UseNftApi['result'] = null;
      let loadMore = defaultLoadMoreApiData;
      let hasMore = false;
      let error: null | Error = null;

      try {
        result = await nftApiMethod(params as any);

        if (result?.nfts?.length && result?.nextPage) {
          hasMore = true;
          loadMore = async () => {
            const nextRequestParams = { ...params, page: result?.nextPage };

            fetchNftApi(method, nextRequestParams);
          };
        }
      } catch (err) {
        error = err as HttpError;
      }

      setIsLoading(false);
      setError(error);
      setResult(result);
      setLoadMore(() => loadMore);
      setHasMore(hasMore);
    }

    fetchNftApi(method, params);
  });

  return { isLoading, error, result, hasMore, loadMore };
}
