import { useState } from 'react';
import { useNftApi } from './useNftApi';
import { Nft } from '../types/services/nfts';
import { useRunOnChange } from './useRunOnChange';

type UseNftsInput = {
  collectionId: string;
};

export function useNfts({ collectionId }: UseNftsInput) {
  const { result, ...state } = useNftApi('getNfts', { collectionId });
  const [tokens, setTokens] = useState<Nft[]>([]);

  useRunOnChange(() => {
    if (result) {
      setTokens([...tokens, ...result.nfts]);
    }
  }, [result]);

  return { tokens, ...state };
}
