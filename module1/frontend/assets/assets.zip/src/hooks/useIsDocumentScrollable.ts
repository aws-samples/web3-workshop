import { useLayoutEffect, useState } from 'react';

/**
 * Hack to force react-infinite-scroll-component to load more items if there aren't enough to show the scrollbar
 * https://github.com/ankeetmaini/react-infinite-scroll-component/issues/217#issuecomment-716966486
 */
export function useIsDocumentScrollable(dependencies: any[]) {
  const elDocumentBody = document.body;
  const [isScrollable, setIsScrollable] = useState<boolean>(false);

  const handleWindowResize = () => {
    setIsScrollable(elDocumentBody.scrollHeight > elDocumentBody.clientHeight);
  };

  window.addEventListener('resize', handleWindowResize);

  useLayoutEffect(() => {
    setIsScrollable(elDocumentBody.scrollHeight > elDocumentBody.clientHeight);

    return () => window.removeEventListener('resize', handleWindowResize);
  }, dependencies);

  return isScrollable;
}
