import { useState } from 'react';
import { transferNft } from '../common/services/api-gateway/api-gateway-nfts';
import toast from 'react-hot-toast';
import { NftInput } from '../types/services/nfts';
import { waitForTransaction, waitForUserOp } from '../common/services/ethereum';

export function useTransferNft({ tokenId, collectionId, rpcProvider }: NftInput) {
  const [isLoading, setIsLoading] = useState(false);

  const promptTransfer = async () => {
    const transferToAddress = prompt(
      `Enter the address you'd like to transfer token ${tokenId} to:`
    );

    if (transferToAddress) {
      setIsLoading(true);

      if (/^0x[a-fA-F0-9]{40}$/.test(transferToAddress)) {
        toast(`Transferring token ${tokenId}...`);

        let transactionHash;

        try {
          const userOpHash = await transferNft({
            collectionId,
            tokenId,
            toAddress: transferToAddress
          });

          try {
            const userOpStatusResult = await waitForUserOp({
              userOpHash,
              toastTextLink: `Transfer token ${tokenId} User Operation`
            });

            transactionHash = userOpStatusResult;
          } catch {
            // Intentionally left blank
            // Tried method handles errors and toasts
          }
        } catch {
          toast.error(`Failed to transfer token ${tokenId}`);
        }

        if (transactionHash) {
          try {
            await waitForTransaction({
              transactionHash,
              rpcProvider,
              toastTextLink: `Transfer token ${tokenId} transaction`
            });
          } catch {
            // Intentionally left blank
            // Tried method handles errors and toasts
          }
        }
      } else {
        toast.error('Please enter a valid Ethereum address');
      }

      setIsLoading(false);
    }
  };

  return { isLoading, promptTransfer };
}
