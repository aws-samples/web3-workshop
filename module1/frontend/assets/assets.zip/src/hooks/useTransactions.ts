import { useState } from 'react';
import { Transaction } from '../types/services/transactions';
import { useRunOnce } from './useRunOnce';
import { getAccountTransactions } from '../common/services/api-gateway/api-gateway-transactions';
import { HttpError } from '../types/errors';

export function useTransactions(address: string) {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<Error>(null);
  const [transactions, setTransactions] = useState<Transaction[]>([]);

  useRunOnce(() => {
    const fetchTransactions = async () => {
      setIsLoading(true);

      try {
        setTransactions(await getAccountTransactions(address));
      } catch (err) {
        setError(err as HttpError);
      } finally {
        setIsLoading(false);
      }
    };

    fetchTransactions();
  });

  return { isLoading, error, transactions };
}
