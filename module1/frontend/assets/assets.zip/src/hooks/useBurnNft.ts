import { useState } from 'react';
import { burnNft } from '../common/services/api-gateway/api-gateway-nfts';
import toast from 'react-hot-toast';
import { NftInput } from '../types/services/nfts';
import { waitForTransaction, waitForUserOp } from '../common/services/ethereum';

export function useBurnNft({ tokenId, collectionId, rpcProvider }: NftInput) {
  const [isLoading, setIsLoading] = useState(false);

  const promptBurn = async () => {
    if (window.confirm(`Are you sure you want to burn NFT ${tokenId}?`)) {
      setIsLoading(true);

      toast(`Burning token ${tokenId}...`);

      let transactionHash = '';

      try {
        const userOpHash = await burnNft({ collectionId, tokenId });

        try {
          const userOpStatusResult = await waitForUserOp({
            userOpHash,
            toastTextLink: `Burn token ${tokenId} User Operation`
          });

          transactionHash = userOpStatusResult;
        } catch {
          // Intentionally left blank
          // Tried method handles errors and toasts
        }
      } catch {
        toast.error(`Failed to burn token ${tokenId}`);
      }

      if (transactionHash) {
        try {
          await waitForTransaction({
            transactionHash,
            rpcProvider,
            toastTextLink: `Burn token ${tokenId} transaction`
          });
        } catch {
          // Intentionally left blank
          // Tried method handles errors and toasts
        }
      }

      setIsLoading(false);
    }
  };

  return { isLoading, promptBurn };
}
