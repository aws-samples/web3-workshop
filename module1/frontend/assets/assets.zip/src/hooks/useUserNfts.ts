import { useState } from 'react';
import { useNftApi } from './useNftApi';
import { useUser } from './useUser';
import { useRunOnChange } from './useRunOnChange';
import { Nft } from '../types/services/nfts';

type UseUserNftsInput = {
  collectionId: string;
};

export function useUserNfts({ collectionId }: UseUserNftsInput) {
  const { user } = useUser();
  const { result, ...state } = useNftApi('getOwnedNfts', {
    collectionId,
    ownerAddress: user.account_address
  });
  const [tokens, setTokens] = useState<Nft[]>([]);

  useRunOnChange(() => {
    if (result) {
      setTokens([...tokens, ...result.nfts]);
    }
  }, [result]);

  return { tokens, ...state };
}
