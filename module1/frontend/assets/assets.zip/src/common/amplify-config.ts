import { Auth } from 'aws-amplify';
import '@aws-amplify/ui-react/styles.css';
import { Constants } from './constants';

export const AMPLIFY_CONFIG = {
  API: {
    endpoints: [
      {
        name: Constants.nftApiName,
        endpoint: import.meta.env.VITE_API_GATEWAY_DOMAIN,
        custom_header: async () => {
          return {
            Authorization: `Bearer ${(await Auth.currentSession()).getIdToken().getJwtToken()}`
          };
        }
      }
    ]
  },
  Auth: {
    region: import.meta.env.VITE_REGION,
    userPoolId: import.meta.env.VITE_USER_POOL_ID,
    userPoolWebClientId: import.meta.env.VITE_USER_POOL_WEB_CLIENT_ID,
    mandatorySignIn: false
  }
};
