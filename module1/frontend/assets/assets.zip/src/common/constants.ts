/* App Contants */

// Set NFT contract addresses to empty string if not deployed.
// This allows for simpler code throughout the app.
// The need for this stems from the CDK that deploys this app relies on SSM Parameter Store,
// which requires the parameters to be available at deploy time and to be set to a non-empty string.

let sentenceNftContractAddress = import.meta.env.VITE_CONTRACT_ADDRESS_SENTENCE_NFT;

if (sentenceNftContractAddress == 'none') {
  sentenceNftContractAddress = '';
}

let genAiNftContractAddress = import.meta.env.VITE_CONTRACT_ADDRESS_GENAI_NFT;

if (genAiNftContractAddress == 'none') {
  genAiNftContractAddress = '';
}

export const Constants = {
  pathHome: '/',
  pathLogin: '/login',
  pathSentenceNft: '/sentence-nft',
  pathGenAiNft: '/gen-ai-nft',
  pathMyWallet: '/my-wallet',
  pathViewNft: '/:collectionId/:tokenId',
  nftApiName: 'NFTApi',
  sentenceNftCollectionId: import.meta.env.VITE_COLLECTION_NAME_SENTENCE_NFT,
  sentenceNftCollectionName: 'Sentence NFT',
  sentenceNftContractAddress: sentenceNftContractAddress,
  genAiNftCollectionId: import.meta.env.VITE_COLLECTION_NAME_GENAI_NFT,
  genAiNftCollectionName: 'Gen AI NFT',
  genAiNftContractAddress: genAiNftContractAddress,
  urlWorkshop: import.meta.env.VITE_URL_WORKSHOP,
  workshopModules: [
    {
      name: 'Sentence NFTs',
      number: 1,
      description:
        'Deploy the core application including an NFT collection smart contract, Amazon Cognito, Amazon API Gateway, AWS Lambda, and more'
    },
    {
      name: 'GenAI NFTs',
      number: 2,
      description:
        'Extend the application to include an NFT collection smart contract that mints generative AI NFTS powered by Amazon SageMaker'
    }
  ],
  surpriseMeText: 'surprise-me',
  surpriseMeTextFriendly: 'Surprise!',
  RPC_PROVIDER: null as any
};
