import { fetchUserOpApiGateway } from './api-gateway';

export async function getUserOpTransactionHash(userOpHash: string) {
  try {
    return fetchUserOpApiGateway('get', `${userOpHash}/transaction-hash`);
  } catch (error) {
    console.error(
      `Failed to get user operation status for hash ${userOpHash}: ${JSON.stringify(error)}`
    );

    return Promise.reject(error);
  }
}
