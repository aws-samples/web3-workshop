import { API } from 'aws-amplify';
import {
  AmplifyApiGatewayRequestInput,
  AmplifyApiGatewayMethod
} from '../../../types/services/amplify-api-gateway';
import { AmplifyHttpError, HttpError } from '../../../types/errors';
import { Constants } from '../../constants';

function getDefaultAmplifyApiGatewayRequestInput(): AmplifyApiGatewayRequestInput {
  return {
    headers: {},
    queryStringParameters: {},
    body: {}
  };
}

function preProcessRequest(input?: AmplifyApiGatewayRequestInput) {
  if (!input) {
    input = getDefaultAmplifyApiGatewayRequestInput();
  }

  return { input };
}

function handleApiGatewayError(amplifyError: unknown) {
  const apiGwError = amplifyError as AmplifyHttpError;
  const error: HttpError = { ...apiGwError, statusCode: apiGwError.response?.status || -1 };

  return error;
}

async function fetchApiGateway(
  method: AmplifyApiGatewayMethod,
  path: string,
  apiName: string,
  input?: AmplifyApiGatewayRequestInput
) {
  const { input: processedInput } = preProcessRequest(input);

  console.log(`Fetching from API Gateway ${apiName}:`, method, path, JSON.stringify(input), '...');

  try {
    return await API[method](apiName, path, processedInput);
  } catch (amplifyError) {
    const error = handleApiGatewayError(amplifyError);

    return Promise.reject(error);
  }
}

export async function fetchNftApiGateway(
  method: AmplifyApiGatewayMethod,
  path: string,
  input?: AmplifyApiGatewayRequestInput
) {
  return fetchApiGateway(method, `tokens/${path}`, Constants.nftApiName, input);
}

export async function fetchUserOpApiGateway(
  method: AmplifyApiGatewayMethod,
  path: string,
  input?: AmplifyApiGatewayRequestInput
) {
  return fetchApiGateway(method, `user-op/${path}`, Constants.nftApiName, input);
}

export async function fetchTransactionsApiGateway(
  method: AmplifyApiGatewayMethod,
  path: string,
  input?: AmplifyApiGatewayRequestInput
) {
  return fetchApiGateway(method, `transactions/${path}`, Constants.nftApiName, input);
}

export async function defaultLoadMoreApiData() {
  console.log("Everything's loaded!");
}
