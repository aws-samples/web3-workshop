import { Transaction } from '../../../types/services/transactions';
import { fetchTransactionsApiGateway } from './api-gateway';

export async function getAccountTransactions(address: string) {
  try {
    const transactions: Transaction[] = await fetchTransactionsApiGateway('get', '', {
      queryStringParameters: { account: address }
    });

    return transactions;
  } catch (error) {
    console.error(`Failed to get transactions for ${address}: ${JSON.stringify(error)}`);

    return Promise.reject(error);
  }
}
