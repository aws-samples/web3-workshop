import {
  MintNftInput,
  NftCollectionInput,
  NftCollectionOwnedInput,
  NftInput,
  NftMintStatusInput,
  NftQueryResponse,
  TransferNftInput
} from '../../../types/services/nfts';
import { fetchNftApiGateway } from './api-gateway';

export async function mintNft({ collectionId, prompt }: MintNftInput) {
  try {
    return fetchNftApiGateway('post', collectionId, { body: { prompt } });
  } catch (error) {
    console.error(
      `Failed to mint NFT from collection ${collectionId} with prompt ${prompt}: ${JSON.stringify(
        error
      )}`
    );

    return Promise.reject(error);
  }
}

export async function getNftMintStatus({ executionArn }: NftMintStatusInput) {
  try {
    return fetchNftApiGateway('get', `status/${encodeURIComponent(executionArn)}`);
  } catch (error) {
    console.error(
      `Failed to get NFT mint status for execution ${executionArn}: ${JSON.stringify(error)}`
    );

    return Promise.reject(error);
  }
}

export async function getNfts({ collectionId, page }: NftCollectionInput) {
  try {
    return fetchNftApiGateway('get', collectionId, {
      queryStringParameters: { page }
    }) as Promise<NftQueryResponse>;
  } catch (error) {
    console.error(`Failed to get NFT collection ${collectionId}: ${JSON.stringify(error)}`);

    return Promise.reject(error);
  }
}

export async function getOwnedNfts({ collectionId, ownerAddress }: NftCollectionOwnedInput) {
  try {
    return fetchNftApiGateway('get', collectionId, {
      queryStringParameters: { owner: ownerAddress }
    }) as Promise<NftQueryResponse>;
  } catch (error) {
    console.error(
      `Failed to get NFT collection ${collectionId} for owner ${ownerAddress}: ${JSON.stringify(
        error
      )}`
    );

    return Promise.reject(error);
  }
}

export async function getNft({ collectionId, tokenId }: NftInput) {
  try {
    return fetchNftApiGateway('get', `${collectionId}/${tokenId}`) as Promise<NftQueryResponse>;
  } catch (error) {
    console.error(`Failed to get NFT ${collectionId} ${tokenId}: ${JSON.stringify(error)}`);

    return Promise.reject(error);
  }
}

export async function transferNft({ collectionId, tokenId, toAddress }: TransferNftInput) {
  try {
    return fetchNftApiGateway('patch', `${collectionId}/${tokenId}`, {
      body: { toAddress }
    });
  } catch (error) {
    console.error(
      `Failed to transfer NFT ${collectionId} ${tokenId} to ${toAddress}: ${JSON.stringify(error)}`
    );

    return Promise.reject(error);
  }
}

export async function burnNft({ collectionId, tokenId }: NftInput) {
  try {
    return fetchNftApiGateway('del', `${collectionId}/${tokenId}`);
  } catch (error) {
    console.error(`Failed to burn NFT ${collectionId} ${tokenId}: ${JSON.stringify(error)}`);

    return Promise.reject(error);
  }
}
