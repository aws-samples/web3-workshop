import toast from 'react-hot-toast';
import { MintNftCheckStatusInput } from '../../types/services/nfts';
import { wait } from '../util';
import { getNftMintStatus, mintNft } from './api-gateway/api-gateway-nfts';
import { waitForTransaction, waitForUserOp } from './ethereum';
import { Constants } from '../constants';

async function checkNftStatusStepFunction(executionArn: string) {
  try {
    const { status, output } = await getNftMintStatus({ executionArn });

    let userOpHash;

    if (status == 'SUCCEEDED' && output) {
      const parsedOutput = JSON.parse(output);

      userOpHash = parsedOutput.MintNFTResult?.TxnHash;

      // Transaction hash can be double JSON encoded

      try {
        userOpHash = JSON.parse(userOpHash);
      } catch {
        // Intentionally left blank
      }
    }

    return { status, userOpHash };
  } catch (error) {
    const errorMessage = 'Mint transaction sent but could not check mint status';

    toast.error(errorMessage);

    return Promise.reject(new Error(error));
  }
}

export async function monitorNftMintStatusStepFunction(
  executionArn: string
): Promise<{ status: string; userOpHash: string }> {
  const { status, userOpHash } = await checkNftStatusStepFunction(executionArn);

  switch (status) {
    case 'SUCCEEDED':
      return Promise.resolve({ status, userOpHash });
    case 'FAILED':
    case 'ABORTED':
    case 'TIMED_OUT':
      return Promise.reject();
    default:
      await wait(3000);

      return monitorNftMintStatusStepFunction(executionArn);
  }
}

export async function mintNftAndMonitorStatus({
  collectionId,
  prompt,
  rpcProvider
}: MintNftCheckStatusInput) {
  const contractAddress = getNftCollectionAddress(collectionId);
  const collectionName = getNftCollectionName(contractAddress);

  toast(`Minting ${collectionName}...`);

  try {
    const mintResult = await mintNft({
      collectionId,
      prompt
    });

    let transactionHash = '';

    const isGenAiNft = collectionId == Constants.genAiNftCollectionId;

    if (isGenAiNft) {
      const { executionArn } = mintResult;

      try {
        const { userOpHash } = await monitorNftMintStatusStepFunction(executionArn);

        try {
          transactionHash = await waitForUserOp({
            userOpHash,
            toastTextLink: 'Gen AI NFT mint User Operation'
          });
        } catch (error) {
          return Promise.reject(error);
        }
      } catch (error) {
        return Promise.reject(error);
      }
    } else {
      const userOpHash = mintResult;

      try {
        transactionHash = await waitForUserOp({
          userOpHash,
          toastTextLink: 'Sentence NFT mint User Operation'
        });
      } catch (error) {
        return Promise.reject(error);
      }
    }

    if (transactionHash) {
      try {
        return waitForTransaction({
          transactionHash,
          rpcProvider,
          toastTextLink: `${collectionName} mint transaction`
        });
      } catch (error) {
        return Promise.reject(error);
      }
    }
  } catch (error) {
    const errorMessage = `Could not mint ${collectionName}`;
    toast.error(errorMessage);

    return Promise.reject(new Error(errorMessage));
  }
}

export function getNftCollectionId(contractAddress: string) {
  let collectionId = '';

  if (contractAddress == Constants.sentenceNftContractAddress) {
    collectionId = Constants.sentenceNftCollectionId || '';
  } else if (contractAddress == Constants.genAiNftContractAddress) {
    collectionId = Constants.genAiNftCollectionId || '';
  }

  return collectionId;
}

export function getNftCollectionName(contractAddress: string) {
  let collectionName = '';

  if (contractAddress == Constants.sentenceNftContractAddress) {
    collectionName = Constants.sentenceNftCollectionName;
  } else if (contractAddress == Constants.genAiNftContractAddress) {
    collectionName = Constants.genAiNftCollectionName;
  }

  return collectionName;
}

export function getNftCollectionAddress(collectionId: string) {
  let contractAddress = '';

  if (collectionId == Constants.sentenceNftCollectionId) {
    contractAddress = Constants.sentenceNftContractAddress || '';
  } else if (collectionId == Constants.genAiNftCollectionId) {
    contractAddress = Constants.genAiNftContractAddress || '';
  }

  return contractAddress;
}
