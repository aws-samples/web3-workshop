import { Auth } from 'aws-amplify';

export const getAmplifyUser = async () => {
  const cognitoUser = await Auth.currentAuthenticatedUser();

  return {
    ...cognitoUser.attributes,
    ...cognitoUser.signInUserSession.idToken.payload
  };
};
