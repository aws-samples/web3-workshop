import toast from 'react-hot-toast';
import { ExternalLink } from '../../components/external-link';
import { ClockIcon } from '@heroicons/react/24/solid';
import { getUserOpTransactionHash } from './api-gateway/api-gateway-user-op';
import { wait } from '../util';

type WaitForTransactionProps = {
  transactionHash: string;
  rpcProvider: any;
  toastTextStart?: string;
  toastTextLink?: string;
};

export async function waitForTransaction({
  transactionHash,
  rpcProvider,
  toastTextStart,
  toastTextLink = 'Transaction'
}: WaitForTransactionProps) {
  const toastJsx = (
    <span>
      {toastTextStart}{' '}
      <ExternalLink
        target={transactionHash}
        href={`https://goerli.etherscan.io/tx/${transactionHash}`}
        className='text-white underline'
      >
        {toastTextLink}
      </ExternalLink>{' '}
      sent! Awaiting confirmation...
    </span>
  );

  toast(toastJsx, {
    icon: <ClockIcon className='h-5 w-5 text-amber-500' />
  });

  if (rpcProvider) {
    try {
      const transactionReceipt = await rpcProvider.waitForTransaction(transactionHash);

      if (transactionReceipt.status) {
        toast.success('Transaction succeeded');

        return transactionReceipt;
      }

      const error = new Error('Transaction failed');

      console.error(error, transactionReceipt);
      toast.error(error.message);

      return Promise.reject(error);
    } catch (err) {
      const error = new Error('Transaction failed to mine');

      console.error(error, err);
      toast.error(error.message);

      return Promise.reject(error);
    }
  } else {
    const error = new Error('Could not connect to RPC provider to check transaction status');

    console.error(error);
    toast.error(error.message);

    return Promise.reject(error);
  }
}

type WaitForUserOpProps = {
  userOpHash: string;
  toastTextStart?: string;
  toastTextLink?: string;
};

export async function waitForUserOp({
  userOpHash,
  toastTextStart = '',
  toastTextLink = 'User Operation'
}: WaitForUserOpProps) {
  const toastJsx = (
    <span>
      {toastTextStart}
      <ExternalLink
        target={userOpHash}
        href={`https://4337.blocknative.com/ops/${userOpHash}`}
        className='text-white underline'
      >
        {toastTextLink}
      </ExternalLink>{' '}
      sent! Awaiting transaction...
    </span>
  );

  toast(toastJsx, {
    icon: <ClockIcon className='h-5 w-5 text-amber-500' />
  });

  const pollUserOp = async (userOpHash: string) => {
    const result = await getUserOpTransactionHash(userOpHash);

    if (!result) {
      await wait(3000);

      return pollUserOp(userOpHash);
    }

    return result;
  };

  try {
    const transactionHash = await pollUserOp(userOpHash);

    return transactionHash;
  } catch {
    const errorMessage =
      'Failed to get transaction hash for user operation. Transaction still likely to succeed...';
    toast.error(errorMessage);

    return Promise.reject(new Error(errorMessage));
  }
}
