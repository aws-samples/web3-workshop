export const joinCssClasses = (...classes: any) => {
  return classes.filter(Boolean).join(' ');
};

export function truncateString(string: string, lengthFront = 6, lengthBack = 4) {
  const stringLength = string.length;
  const firstPart = string.substring(0, lengthFront);
  const lastPart = string.substring(stringLength - lengthBack, stringLength);

  return `${firstPart}...${lastPart}`;
}

export const wait = (milliseconds: number) => {
  return new Promise((resolve) => setTimeout(resolve, milliseconds));
};

export const defer = (callback: () => unknown, milliseconds?: number) => {
  setTimeout(callback, milliseconds);
};

export function capitalize(string: string): string {
  return string.charAt(0).toUpperCase() + string.slice(1);
}
