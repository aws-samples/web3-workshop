// eslint-disable-next-line spaced-comment
/// <reference types="vite/client" />
