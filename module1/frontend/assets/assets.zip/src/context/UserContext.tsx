import { createContext, useState } from 'react';
import { getAmplifyUser } from '../common/services/amplify';
import { useRunOnce } from '../hooks/useRunOnce';
import { Auth } from 'aws-amplify';

type UserContextType = {
  isLoading: boolean;
  isAuthenticated: boolean;
  user: any;
  getAndSetUser: () => Promise<void>;
  signOut: () => Promise<void>;
};

const initialState: UserContextType = {
  isLoading: false,
  isAuthenticated: false,
  user: {},
  getAndSetUser: () => Promise.resolve(),
  signOut: () => Promise.resolve()
};

const UserContext = createContext<UserContextType>(initialState);

const UserContextProvider: React.FC<React.HTMLProps<HTMLElement>> = ({
  children
}: React.HTMLProps<HTMLElement>) => {
  const [isLoading, setIsLoading] = useState(initialState.isLoading);
  const [isAuthenticated, setIsAuthenticated] = useState(initialState.isAuthenticated);
  const [user, setUser] = useState(initialState.user);

  const getAndSetUser = async () => {
    setIsLoading(true);

    try {
      const user = await getAmplifyUser();

      setUser(user);
      setIsAuthenticated(true);
    } catch (error) {
      console.error(error);
    }

    setIsLoading(false);
  };

  const signOut = async () => {
    setIsLoading(true);

    await Auth.signOut();

    setUser(null);
    setIsAuthenticated(false);
    setIsLoading(false);
  };

  useRunOnce(() => {
    getAndSetUser();
  });

  return (
    <UserContext.Provider
      value={{
        isLoading,
        isAuthenticated,
        user,
        getAndSetUser,
        signOut
      }}
    >
      {children}
    </UserContext.Provider>
  );
};

export { UserContext, UserContextProvider };
