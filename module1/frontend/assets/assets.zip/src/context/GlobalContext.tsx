import { createContext } from 'react';
import { useSDK } from '@thirdweb-dev/react';
import { UserContextProvider } from './UserContext';
import { Constants } from '../common/constants';

const GlobalContext = createContext(null);

const GlobalContextProvider: React.FC<React.HTMLProps<HTMLElement>> = ({
  children
}: React.HTMLProps<HTMLElement>) => {
  const THIRD_WEB_SDK = useSDK();
  const RPC_PROVIDER = THIRD_WEB_SDK?.getProvider();

  Constants.RPC_PROVIDER = RPC_PROVIDER;

  return (
    <GlobalContext.Provider value={null}>
      <UserContextProvider>{children}</UserContextProvider>
    </GlobalContext.Provider>
  );
};

export { GlobalContextProvider };
