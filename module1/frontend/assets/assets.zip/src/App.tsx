import { Suspense } from 'react';
import './App.css';
import { RouterProvider } from 'react-router-dom';
import { Amplify } from 'aws-amplify';
import { getRouter } from './router';
import { AMPLIFY_CONFIG } from './common/amplify-config';
import { useUser } from './hooks/useUser';
import toast, { Toaster, resolveValue } from 'react-hot-toast';
import {
  InformationCircleIcon,
  ExclamationCircleIcon,
  CheckCircleIcon,
  XMarkIcon
} from '@heroicons/react/24/solid';
import { Authenticator } from '@aws-amplify/ui-react';

Amplify.configure(AMPLIFY_CONFIG);

function App() {
  const { isAuthenticated } = useUser();

  return (
    <Suspense>
      <Toaster
        toastOptions={{
          duration: Infinity,
          position: 'bottom-right',
          icon: <InformationCircleIcon className='h-5 w-5 text-blue-500' />,
          success: {
            icon: <CheckCircleIcon className='h-5 w-5 text-green-500' />
          },
          error: {
            icon: <ExclamationCircleIcon className='h-5 w-5 text-red-500' />
          }
        }}
      >
        {(t) => (
          <div
            className={
              'flex items-center gap-2 p-4 bg-slate-700 text-white rounded-md shadow-lg max-w-lg pointer-events-auto ring-1 ring-slate-300 animate-in fade-in-75 zoom-in-75'
            }
          >
            {resolveValue(t.icon, t)}
            {resolveValue(t.message, t)}
            <button onClick={() => toast.remove(t.id)}>
              <XMarkIcon className='h-5 w-5 text-white' />
            </button>
          </div>
        )}
      </Toaster>
      <Authenticator.Provider>
        <RouterProvider router={getRouter(isAuthenticated)} />
      </Authenticator.Provider>
    </Suspense>
  );
}

export default App;
