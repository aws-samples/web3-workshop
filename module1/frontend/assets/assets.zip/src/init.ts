/**
 * This script is imported in index.html BEFORE main.tsx. This is a requirement because:
 *
 *    1. The @aws-amplify library assumes the NodeJS 'global' variable will be present (likely because it relies on webpack)
 *    2. Vite doesn't define 'global' as webpack does
 *
 * The below line sets 'global' to the browser 'window' object so Amplify has what it needs.
 */

window.global ||= window;
