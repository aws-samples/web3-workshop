# Web3 Workshop Web App

This project contains the source code for the Web3 on AWS Workshop Web App. Its built using Vite.js, React, TypeScript, and Tailwind CSS.

## Solution Overview

- Signup/Login to a Cognito User Pool with the AWS Amplify UI Library
- Make authenticated API requests to API Gateway with the Amplify Javascript library
- Interact with the NFT contracts deployed during the Web3 on AWS Workshop
  - View contract NFTs
  - View owned NFTs
  - Mint NFTs
  - Transfer NFTs
  - Burn NFTs
  - View transactions

## Preqrequisites

- [Node.js](https://nodejs.org/en/download/)
- Complete and deploy module 1 of the Web3 on AWS Workshop

## Developer prerequisites

There are a few tools that should be used to enhance developer experience:

- VS Code
- VS Code extensions:
  - [ESLint](https://marketplace.visualstudio.com/items?itemName=dbaeumer.vscode-eslint)
    - Used to highlight and fix TypeScript code
  - [Prettier](https://marketplace.visualstudio.com/items?itemName=esbenp.prettier-vscode)
    - Used to format code
    - Code is always formatted before every commit
    - If using VS Code, the `/.vscode/settings.json` file includes settings to format when pasting and saving code

## Getting Started

Run the following commands to get the project ready for development.

### Install dependencies

```
npm install
```

- Installs project dependenceies

### Environment variables

This project is reliant on environment variables for configuration. The web app gets information like contract addresses, API Gateway invoke urls, and Cognito User Pool details via environment variables.

Environment variables are defined by a gitignored-file named `.env`. To create your `.env` file:

1. Copy the contents of `.env.sample` found in the root of this project
2. Create a new file named `.env` in the project root
3. Paste the contents of `.env.sample` into `.env`
4. Add values for each environment variable defined in `.env`
   - These values can be found in the AWS Amplify Console under the `Environment Variables` section

## Development

```
npm start
```

- Runs the app in development mode
- Should automatically open a browser to [http://localhost:5174/](http://localhost:5174/)
- The page will automically reload as you make changes and save files

```
npm run build
```

- Build the app for production to the `/dist` directory
- Typically ran in CI/CD pipelines before publishing the build artifacts to deploy the web app
- See the Vite docs for more: https://vitejs.dev/guide/build.html
